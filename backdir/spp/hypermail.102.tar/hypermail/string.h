/*
** Copyright (C) 1994, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 7/28/94
*/

char *strdup();
char *stripzone();
int numstrchr();
char *convurls();
char *convchars();
char *unconvchars();
char *getconfvalue();
char *getvalue();
char *unre();
void oneunre();
char *rmcr();
int isquote();
char *replace();
char *makemailcommand();
