/*
** Copyright (C) 1994, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 7/20/94
*/

void loadheaders();
void loadoldheaders();
char *getmaildate();
char *getfromdate();
void getname();
char *getid();
char *getsubject();
char *getreply();
void crossindex();
void crossindexthread1();
void crossindexthread2();
void fixnextheader();
void fixreplyheader();
void fixthreadheader();
