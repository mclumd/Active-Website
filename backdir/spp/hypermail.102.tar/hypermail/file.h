/*
** Copyright (C) 1994, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com
** 7/17/94
*/

int isdirectory();
int isfile();
void checkdir();
void readconfigs();
