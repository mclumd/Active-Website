/*
** Copyright (C) 1994, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 7/14/94
*/

void writearticles();
void printbody();
void writedates();
void printdates();
void writethreads();
void printthreads();
void writesubjects();
void printsubjects();
void writeauthors();
void printauthors();
void checkreplies();
char *makefilename();
void printcomment();
void printfooter();
void progerr();
void usage();
