
/**
 * This class keeps track of global information, not colors or fonts
 * @author K. Purang
 * @version October 2000
 */

public class Globals{
    public static boolean verbose;
    public static AbGui theGui;
    
}
