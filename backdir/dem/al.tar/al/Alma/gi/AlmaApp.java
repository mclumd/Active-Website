/*
  For an application
*/


public class AlmaApp{

    public static void main(String args[]){
	GuiApp theApp = new GuiApp(args);
    }

}
