% simple_alarm.pl

if(now(10), lunch).

