% whenever set_alarm(t) is asserted, the alarm will go off at the set
% time.


if(lunch_at(T), alma(af(if(now(T), lunch)))).



