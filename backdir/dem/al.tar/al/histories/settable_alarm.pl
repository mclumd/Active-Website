% whenever set_alarm(t) is asserted, the alarm will go off at the set
% time.
% compare with the other version.

if(and(lunch_at(X), now(X)), lunch).

