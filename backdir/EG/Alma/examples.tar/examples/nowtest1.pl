% test for now
% note the delay before this is printed.

if(now(3), alma(format('~n~nIt is now 3~n~n', []))).

