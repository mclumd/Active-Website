# LaTeX2HTML 99.2beta6 (1.42)
# Associate internals original text with physical files.


$key = q/cite_kraus_nirkhe_perlis:deadline-coupled/;
$ref_files{$key} = "$dir".q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_elgot-drapkin_kraus_miller:active/;
$ref_files{$key} = "$dir".q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_wolpert_macready1997:no_free/;
$ref_files{$key} = "$dir".q|node1.html|; 
$noresave{$key} = "$nosave";

1;

