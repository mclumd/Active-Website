# LaTeX2HTML 99.2beta6 (1.42)
# Associate labels original text with physical files.


$key = q/cite_kraus_nirkhe_perlis:deadline-coupled/;
$external_labels{$key} = "$URL/" . q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_elgot-drapkin_kraus_miller:active/;
$external_labels{$key} = "$URL/" . q|node1.html|; 
$noresave{$key} = "$nosave";

$key = q/cite_wolpert_macready1997:no_free/;
$external_labels{$key} = "$URL/" . q|node1.html|; 
$noresave{$key} = "$nosave";

1;


# LaTeX2HTML 99.2beta6 (1.42)
# labels from external_latex_labels array.


1;

